/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solent.ac.uk.com504.examples.dao.jaxb;

import java.io.File;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import solent.ac.uk.com504.examples.ticketgate.dao.jpa.DAOImpl;
import solent.ac.uk.com504.examples.ticketgate.model.dao.ConfigurationDAO;
import solent.ac.uk.com504.examples.ticketgate.model.dto.Configuration;
import solent.ac.uk.com504.examples.ticketgate.model.dto.Gate;
import solent.ac.uk.com504.examples.ticketgate.model.dto.RateSchedule;
import solent.ac.uk.com504.examples.ticketgate.model.dto.Station;
import solent.ac.uk.com504.examples.ticketgate.model.dto.TicketMachine;

/**
 *
 * @author songo
 */
public class DAOJaxbImpl extends DAOImpl implements ConfigurationDAO{
    
    final static Logger LOG = LogManager.getLogger(DAOJaxbImpl.class);

    private String filePath = null;
    private File file;

    private JAXBContext jaxbContext;
    private Marshaller jaxbMarshaller;
    private Unmarshaller jaxbUnMarshaller;
    
     public DAOJaxbImpl(String filePath) {

        super();

        file = new File(filePath);
        LOG.info("jaxb dao using file=" + file.getAbsolutePath());

        // create JAXB contexts and marshallers
        try {
            // this contains a list of Jaxb annotated classes for the context to parse
            // NOTE you must also have a jaxb.index or ObjectFactory in the same classpath
            jaxbContext = JAXBContext.newInstance("solent.ac.uk.com504.examples.ticketgate.model.dto");

            jaxbMarshaller = jaxbContext.createMarshaller();
            // output pretty printed
            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

            jaxbUnMarshaller = jaxbContext.createUnmarshaller();

        } catch (JAXBException e) {
            throw new RuntimeException("problem setting up jaxb marshalling", e);
        }

        this.filePath = filePath;
        load();
    }
     
      private void load() {

        // create a new file if file doesn't exist
        if (!file.exists()) {
            LOG.info("file does not exist. New file created=" + file.getAbsolutePath());
            save();
            return;
        }

        // load file
        try {
            // create XML from the object
            // marshal the object lists to system out, a file and a stringWriter

            // read in the file to animal list
//            Unmarshaller jaxbUnMarshaller = jaxbContext.createUnmarshaller();
            this.configList = (Configuration) jaxbUnMarshaller.unmarshal(file);

        } catch (JAXBException e) {
            throw new RuntimeException("problem testing jaxb marshalling", e);
        }

    }
      
     private void save() {
        // savefile
        try {
            // create XML from the object
            // marshal the object lists to system out, a file and a stringWriter
            jaxbMarshaller.marshal(this.configList, file);

        } catch (JAXBException e) {
            throw new RuntimeException("problem testing jaxb marshalling", e);
        }

    }

    @Override
    public synchronized Gate retrieveGateById(Long id) {
        return super.retrieveGateById(id);
    }     
    
    @Override
    public synchronized Gate updateOrSave(Gate gate) {
        Gate updatedGate = super.updateOrSave(gate);
        save(); // saves updated list
        return updatedGate;
    }
    
    @Override
    public synchronized boolean deleteGateById(long id) {
       boolean deletedGate = super.deleteGateById(id);
        save(); // saves updated list
        return deletedGate;
    }
    
    @Override
    public synchronized List<Gate> retrieveAllGates() {
        List<Gate> returnedGates = super.retrieveAllGates();
        return returnedGates;
    }
    
    @Override
    public Gate createGate() {
        Gate createdGate = super.createGate();
        save();
        return createdGate;
    }
    
    @Override
    public boolean openOrCloseGates(Gate openGate){
        return super.openOrCloseGates(openGate);
    }
    
    @Override
    public synchronized Station retrieveStationById(Long id) {
        return super.retrieveStationById(id);
    }
    
    @Override
    public synchronized Station updateOrSave(Station station) {
        Station updatedStation = super.updateOrSave(station);
        save(); // saves updated list
        return updatedStation;
    }
    
    @Override
    public synchronized boolean deleteStationById(long id) {
        boolean deletedStation = super.deleteStationById(id);
        save(); // saves updated list
        return deletedStation;
    }
    
    @Override
    public synchronized List<Station> retrieveAllStations() {
        List<Station> returnedStations = super.retrieveAllStations();
        return returnedStations;
    }
    
    @Override
    public Station createStation() {
        Station createdStation = super.createStation();
        save();
        return createdStation;
    }
    
    @Override
    public synchronized TicketMachine retrieveTicketMachineById(Long id) {
        return super.retrieveTicketMachineById(id);
    }

    @Override
    public synchronized TicketMachine updateOrSave(TicketMachine ticketMachine) {
        TicketMachine updatedTicketMachine = super.updateOrSave(ticketMachine);
        save(); // saves updated list
        return updatedTicketMachine;
    }

    @Override
    public synchronized boolean deleteTicketMachineById(long id) {
        boolean deletedTicketMachine = super.deleteTicketMachineById(id);
        save(); // saves updated list
        return deletedTicketMachine;
    }

    @Override
    public synchronized List<TicketMachine> retrieveAllTicketMachines() {
        List<TicketMachine> returnedTicketMachines = super.retrieveAllTicketMachines();
        return returnedTicketMachines;
    }
    
    @Override
    public TicketMachine createTicketMachine() {
        TicketMachine createdTicketMachine = super.createTicketMachine();
        save();
        return createdTicketMachine;
    }
    
    @Override
    public synchronized RateSchedule retrieveRateScheduleById(Long id) {
        return super.retrieveRateScheduleById(id);
    }    
    
    @Override
    public synchronized RateSchedule createRateSchedule(int day, int hour){
        RateSchedule createdRateSchedule = super.createRateSchedule(day, hour);
        save();
        return createdRateSchedule;
    }
}

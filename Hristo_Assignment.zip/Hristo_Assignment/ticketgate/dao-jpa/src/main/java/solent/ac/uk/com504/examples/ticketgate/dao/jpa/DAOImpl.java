/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solent.ac.uk.com504.examples.ticketgate.dao.jpa;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import solent.ac.uk.com504.examples.ticketgate.model.dao.ConfigurationDAO;
import solent.ac.uk.com504.examples.ticketgate.model.dto.Configuration;
import solent.ac.uk.com504.examples.ticketgate.model.dto.Gate;
import solent.ac.uk.com504.examples.ticketgate.model.dto.RateSchedule;
import solent.ac.uk.com504.examples.ticketgate.model.dto.Station;
import solent.ac.uk.com504.examples.ticketgate.model.dto.TicketMachine;

/**
 *
 * @author songo
 */
public class DAOImpl implements ConfigurationDAO {
    
    protected Configuration configList = new Configuration();
    
    @Override
    public Gate retrieveGateById(Long id) {
         for (Gate gate : configList.getGateList()) {
            if (id.equals(gate.getId())) {
                
                return gate;
            }
        }
        return null;
    }

    @Override
    public Gate updateOrSave(Gate gate) {
        Gate update = null;
        Long id = gate.getId();

        
        if (id != null) {
            update = retrieveGateById(gate.getId());

 
            if (update == null) {
                throw new RuntimeException("cannot retrieve Gate with unknown id=" + gate);
            }

        } else {

            update = gate;
            id = configList.getCurrentMaxId();
            id++;
            configList.setCurrentMaxId(id);
            update.setId(id);
            configList.getGateList().add(update);
        }

        return update;
    }

    @Override
    public synchronized boolean deleteGateById(long id) {
        ListIterator<Gate> gateIterator = configList.getGateList().listIterator();
        while (gateIterator.hasNext()) {
            Gate gate = gateIterator.next();
            if (id == gate.getId()) {
                
                gateIterator.remove();
                
                return true;
            }
        }
        
        return false;
    }

    @Override
    public synchronized List<Gate> retrieveAllGates() {
        return new ArrayList<Gate>(configList.getGateList());
    }

    @Override
    public synchronized Gate createGate(){
        Gate gate = new Gate();
        gate.setId(gate.getId());
        gate.setStationId(gate.getStationId());
        gate.setOpenGate(false);
        return gate;
    }
    
    @Override
    public synchronized boolean openOrCloseGates(Gate openGate){
            if(Boolean.valueOf(true).equals(openGate.isOpenGate())){
                return openGate.isOpenGate();
                
            
        }
        return false;
    }
    
    @Override
    public Station retrieveStationById(Long id) {
         for (Station station : configList.getStationList()) {
            if (id.equals(station.getId())) {
                
                return station;
            }
        }
        return null;
    }

    @Override
    public Station updateOrSave(Station station) {
        Station update = null;
        Long id = station.getId();

        
        if (id != null) {
            update = retrieveStationById(station.getId());

 
            if (update == null) {
                throw new RuntimeException("cannot retrieve Station with unknown id=" + station);
            }

        } else {

            update = station;
            id = configList.getCurrentMaxId();
            id++;
            configList.setCurrentMaxId(id);
            update.setId(id);
            configList.getStationList().add(update);
        }

        return update;
    }

    @Override
    public synchronized boolean deleteStationById(long id) {
        ListIterator<Station> stationIterator = configList.getStationList().listIterator();
        while (stationIterator.hasNext()) {
            Station station = stationIterator.next();
            if (id == station.getId()) {
                
                stationIterator.remove();
                
                return true;
            }
        }
        
        return false;
    }

    @Override
    public List<Station> retrieveAllStations() {
        return new ArrayList<Station>(configList.getStationList());
    }
    
    @Override
    public synchronized Station createStation(){
        Station station = new Station();
        station.setId(station.getId());
        station.setStationName(station.getStationName());
        station.setZone(station.getZone());
        station.setRateSchedule(station.getRateSchedule());
        return station;
    }

    @Override
    public TicketMachine retrieveTicketMachineById(Long id) {
        for (TicketMachine ticketMachine : configList.getTicketMachineList()) {
            if (id.equals(ticketMachine.getId())) {
                
                return ticketMachine;
            }
        }
        return null;
       }

    @Override
    public TicketMachine updateOrSave(TicketMachine ticketMachine) {
        TicketMachine update = null;
        Long id = ticketMachine.getId();

        
        if (id != null) {
            update = retrieveTicketMachineById(ticketMachine.getId());

 
            if (update == null) {
                throw new RuntimeException("cannot retrieve TicketMachine with unknown id=" + ticketMachine);
            }

        } else {

            update = ticketMachine;
            id = configList.getCurrentMaxId();
            id++;
            configList.setCurrentMaxId(id);
            update.setId(id);
            configList.getTicketMachineList().add(update);
        }

        return update;
    }

    @Override
    public synchronized boolean deleteTicketMachineById(long id) {
        ListIterator<TicketMachine> ticketMachineIterator = configList.getTicketMachineList().listIterator();
        while (ticketMachineIterator.hasNext()) {
            TicketMachine ticketMachine = ticketMachineIterator.next();
            if (id == ticketMachine.getId()) {
                
                ticketMachineIterator.remove();
                
                return true;
            }
        }
        
        return false;
    }

    @Override
    public List<TicketMachine> retrieveAllTicketMachines() {
         return new ArrayList<TicketMachine>(configList.getTicketMachineList());
    }
    
    @Override
    public synchronized TicketMachine createTicketMachine(){
        TicketMachine ticketMachine = new TicketMachine();
        ticketMachine.setId(ticketMachine.getId());
        ticketMachine.setStationId(ticketMachine.getStationId());
        ticketMachine.setOpenTicketMachine(true);
        return ticketMachine;
    }

    @Override
    public synchronized RateSchedule retrieveRateScheduleById(Long id) {
         for (RateSchedule rateSchedule : configList.getRateSchedyleList()) {
            if (id.equals(rateSchedule.getId())) {
                
                return rateSchedule;
            }
        }
        return null;
    }
    @Override
    public RateSchedule updateOrSave(RateSchedule rateSchedule){
           RateSchedule update = null;
        Long id = rateSchedule.getId();

        
        if (id != null) {
            update = retrieveRateScheduleById(rateSchedule.getId());

 
            if (update == null) {
                throw new RuntimeException("cannot retrieve RateSchedule with unknown id=" + rateSchedule);
            }

        } else {

            update = rateSchedule;
            id = configList.getCurrentMaxId();
            id++;
            configList.setCurrentMaxId(id);
            update.setId(id);
            configList.getRateSchedyleList().add(update);
        }

        return update;
    }

    @Override
    public RateSchedule createRateSchedule(int day, int hour) {
        RateSchedule rateSchedule = new RateSchedule();
        rateSchedule.setId(rateSchedule.getId());
        rateSchedule.setIsOnPeak(day, hour, rateSchedule.isOnPeak(day, hour));
        
        return rateSchedule;
    }
    
}

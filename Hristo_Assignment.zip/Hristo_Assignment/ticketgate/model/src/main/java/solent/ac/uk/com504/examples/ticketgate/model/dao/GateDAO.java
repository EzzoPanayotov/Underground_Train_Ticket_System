/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solent.ac.uk.com504.examples.ticketgate.model.dao;

import java.util.List;
import solent.ac.uk.com504.examples.ticketgate.model.dto.Gate;

/**
 *
 * @author songo
 */
public interface GateDAO {
    
    /**
     *
     * @param id
     * @return
     */
    public Gate retrieveGateById(Long id);
    
    /**
     *
     * @param gate
     * @return
     */
    public Gate updateOrSave(Gate gate);
    
    /**
     *
     * @param id
     * @return
     */
    public boolean deleteGateById(long id);
    
    /**
     *
     * @return
     */
    public List<Gate> retrieveAllGates();
    
    /**
     *
     * @return
     */
    public Gate createGate();
    
    /**
     *
     * @param openGate
     * @return
     */
    public boolean openOrCloseGates(Gate openGate);
    
}

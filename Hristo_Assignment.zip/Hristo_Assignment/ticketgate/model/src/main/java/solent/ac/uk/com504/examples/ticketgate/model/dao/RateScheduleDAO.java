/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solent.ac.uk.com504.examples.ticketgate.model.dao;

import solent.ac.uk.com504.examples.ticketgate.model.dto.RateSchedule;

/**
 *
 * @author songo
 */
public interface RateScheduleDAO {
    
    /**
     *
     * @param id
     * @return
     */
    public RateSchedule retrieveRateScheduleById(Long id);
    
    public RateSchedule createRateSchedule(int day, int hour);
    
     public RateSchedule updateOrSave(RateSchedule rateSchedule);
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solent.ac.uk.com504.examples.ticketgate.model.dao;

import java.util.List;
import solent.ac.uk.com504.examples.ticketgate.model.dto.TicketMachine;

/**
 *
 * @author songo
 */
public interface TicketMachineDAO {
    
    /**
     *
     * @param id
     * @return
     */
    public TicketMachine retrieveTicketMachineById(Long id);
    
    /**
     *
     * @param ticketMachine
     * @return
     */
    public TicketMachine updateOrSave(TicketMachine ticketMachine);
    
    /**
     *
     * @param id
     * @return
     */
    public boolean deleteTicketMachineById(long id);
    
    /**
     *
     * @return
     */
    public List<TicketMachine> retrieveAllTicketMachines();
    
    /**
     *
     * @return
     */
    public TicketMachine createTicketMachine();
}

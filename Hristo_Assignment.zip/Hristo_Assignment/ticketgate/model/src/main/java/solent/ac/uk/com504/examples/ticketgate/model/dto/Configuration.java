/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solent.ac.uk.com504.examples.ticketgate.model.dto;

import java.util.ArrayList;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author songo
 */

@XmlRootElement(name = "configList")
@XmlAccessorType(XmlAccessType.FIELD)
public class Configuration {
    
    @XmlElementWrapper(name = "stationList")
    @XmlElement(name = "station")
    private ArrayList<Station> stationList = new ArrayList<Station>();
    
    @XmlElementWrapper(name = "ticketMachineList")
    @XmlElement(name = "ticketMachine")
    private ArrayList<TicketMachine> ticketMachineList = new ArrayList<TicketMachine>();
    
    @XmlElementWrapper(name = "gateList")
    @XmlElement(name = "gate")
    private ArrayList<Gate> gateList = new ArrayList<Gate>();
    
    @XmlElementWrapper(name = "rateScheduleList")
    @XmlElement(name = "rateSchedule")
    private ArrayList<RateSchedule> rateSchedyleList = new ArrayList<RateSchedule>();
    
    private Long currentMaxId = 0L;
    
    /**
     *
     * @return
     */
    public ArrayList<Station> getStationList() {
        return stationList;
    }

    /**
     *
     * @param stationList
     */
    public void setStationList(ArrayList<Station> stationList) {
        this.stationList = stationList;
    }

    /**
     *
     * @return
     */
    public ArrayList<TicketMachine> getTicketMachineList() {
        return ticketMachineList;
    }

    /**
     *
     * @param ticketMachineList
     */
    public void setTicketMachineList(ArrayList<TicketMachine> ticketMachineList) {
        this.ticketMachineList = ticketMachineList;
    }

    /**
     *
     * @return
     */
    public ArrayList<Gate> getGateList() {
        return gateList;
    }

    /**
     *
     * @param gateList
     */
    public void setGateList(ArrayList<Gate> gateList) {
        this.gateList = gateList;
    }

    /**
     *
     * @return
     */
    public Long getCurrentMaxId() {
        return currentMaxId;
    }

    /**
     *
     * @param currentMaxId
     */
    public void setCurrentMaxId(Long currentMaxId) {
        this.currentMaxId = currentMaxId;
    }

    /**
     *
     * @return
     */
    public ArrayList<RateSchedule> getRateSchedyleList() {
        return rateSchedyleList;
    }

    /**
     *
     * @param rateSchedyleList
     */
    public void setRateSchedyleList(ArrayList<RateSchedule> rateSchedyleList) {
        this.rateSchedyleList = rateSchedyleList;
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return "Configuration{" + "stationList=" + stationList + ", ticketMachineList=" + ticketMachineList + ", gateList=" + gateList + ", currentMaxId=" + currentMaxId + '}';
    }
    
    
}

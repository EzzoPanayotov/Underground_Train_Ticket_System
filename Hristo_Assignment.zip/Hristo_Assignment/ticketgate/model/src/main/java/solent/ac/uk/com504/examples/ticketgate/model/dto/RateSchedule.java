/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solent.ac.uk.com504.examples.ticketgate.model.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author songo
 */


@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class RateSchedule {

    private Long id;
    
    private boolean[][] schedule = new boolean[7][24];

    /**
     *
     * @return
     */
    public Long getId() {
        return id;
    }

    /**
     *
     * @param id
     */
    public void setId(Long id) {
        this.id = id;
    }
    
    /**
     *
     * @return
     */
    public boolean[][] getSchedule() {
        return schedule;
    }
    
    /**
     *
     * @param schedule
     */
    public void setSchedule(boolean[][] schedule) {
        this.schedule = schedule;
    }
    
    /**
     *
     * @param day
     * @param hour
     * @return
     */
    public boolean isOnPeak(int day, int hour){
        return schedule[day][hour];
    }
    
    /**
     *
     * @param day
     * @param hour
     * @param isOnPeak
     */
    public void setIsOnPeak(int day, int hour, boolean isOnPeak){
        schedule[day][hour] = isOnPeak;
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return "RateSchedule{" + "schedule=" + schedule + '}';
    }
    
}

package solent.ac.uk.com504.examples.ticketgate.model.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author songo
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class ReplyMessage {

    private Integer code;

    private String debugMessage;

    private Boolean unlocked;

    private Ticket ticket;

    /**
     *
     * @return
     */
    public Integer getCode() {
        return code;
    }

    /**
     *
     * @param code
     */
    public void setCode(Integer code) {
        this.code = code;
    }

    /**
     *
     * @return
     */
    public String getDebugMessage() {
        return debugMessage;
    }

    /**
     *
     * @param debugMessage
     */
    public void setDebugMessage(String debugMessage) {
        this.debugMessage = debugMessage;
    }

    /**
     *
     * @return
     */
    public Boolean getUnlocked() {
        return unlocked;
    }

    /**
     *
     * @param unlocked
     */
    public void setUnlocked(Boolean unlocked) {
        this.unlocked = unlocked;
    }

    /**
     *
     * @return
     */
    public Ticket getTicket() {
        return ticket;
    }

    /**
     *
     * @param ticket
     */
    public void setTicket(Ticket ticket) {
        this.ticket = ticket;
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return "ReplyMessage{" + "code=" + code + ", debugMessage=" + debugMessage + ", unlocked=" + unlocked + ", ticket=" + ticket + '}';
    }


    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solent.ac.uk.com504.examples.ticketgate.model.dto;

/**
 *
 * @author songo
 */

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author songo
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)

public class Station {
    
    private Long id;
    
    private String stationName;
    
    private int zone;
    
    private RateSchedule rateSchedule;
    
    //Made it int because we have to use it to calculate the price of a ticket

    /**
     * Gets the station id
     * @return Long representing station id
     */

    public int getDistance(Station station){
        return (int) Math.abs(this.getZone() - station.getZone());
    }
    public Long getId() {
        return id;
    }

    /**
     * Sets the station id
     * @param id Long containing station id
     */
    public void setId(Long id) {
        this.id = id;
    }
    
    /**
     * Gets the station name
     * @return String representing the station name
     */
    public String getStationName() {
        return stationName;
    }

    /**
     * 
     * @param stationName sets station name
     */
    public void setStationName(String stationName) {
        this.stationName = stationName;
    }

    /**
     * returns station zone
     * @return
     */
    public int getZone() {
        return zone;
    }

    /**
     * sets station zone
     * @param zone
     */
    public void setZone(int zone) {
        this.zone = zone;
    }

    /**
     * returns rate schedule
     * @return
     */
    public RateSchedule getRateSchedule() {
        return rateSchedule;
    }
    
    /**
     *
     * @param rateSchedule
     */
    public void setRateSchedule(RateSchedule rateSchedule){
        this.rateSchedule = rateSchedule;
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return "Station{" + "id=" + id + ", stationName=" + stationName + ", zone=" + zone + ", rateSchedule=" + rateSchedule + '}';
    }
    
}

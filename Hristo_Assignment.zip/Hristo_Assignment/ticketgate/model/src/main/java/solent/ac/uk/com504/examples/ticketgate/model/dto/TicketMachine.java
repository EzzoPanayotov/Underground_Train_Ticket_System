/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solent.ac.uk.com504.examples.ticketgate.model.dto;

/**
 *
 * @author songo
 */

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author songo
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class TicketMachine {
    
    private Long id;
    
    private Long stationId;
    
    private boolean openTicketMachine;

    /**
     *
     * @return
     */
    public Long getId() {
        return id;
    }

    /**
     *
     * @param id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     *
     * @return
     */
    public Long getStationId() {
        return stationId;
    }

    /**
     *
     * @param stationId
     */
    public void setStationId(Long stationId) {
        this.stationId = stationId;
    }

    /**
     *
     * @return
     */
    public boolean isOpenTicketMachine() {
        return openTicketMachine;
    }

    /**
     *
     * @param openTicketMachine
     */
    public void setOpenTicketMachine(boolean openTicketMachine) {
        this.openTicketMachine = openTicketMachine;
    }
    
    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return "TicketMachine{" + "id=" + id + ", stationId=" + stationId + '}';
    }
    
}

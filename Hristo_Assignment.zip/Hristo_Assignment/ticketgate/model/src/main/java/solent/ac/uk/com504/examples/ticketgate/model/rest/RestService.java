package solent.ac.uk.com504.examples.ticketgate.model.rest;

import solent.ac.uk.com504.examples.ticketgate.model.dto.Ticket;
import solent.ac.uk.com504.examples.ticketgate.model.dto.ReplyMessage;

/**
 *
 * @author songo
 */
public interface RestService {

    /**
     *
     * @param ticket
     * @return
     */
    public ReplyMessage openGate(Ticket ticket);

    /**
     *
     * @return
     */
    public ReplyMessage createTicket();
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solent.ac.uk.com504.examples.ticketgate.model.service;

import java.util.List;
import solent.ac.uk.com504.examples.ticketgate.model.dto.Gate;
import solent.ac.uk.com504.examples.ticketgate.model.dto.RateSchedule;
import solent.ac.uk.com504.examples.ticketgate.model.dto.Station;
import solent.ac.uk.com504.examples.ticketgate.model.dto.TicketMachine;

/**
 *
 * @author songo
 */
public interface ConfigurationService {
    // get Gate, station, TicketMachine, rateSchedule by Id

    /**
     *
     * @param id
     * @return
     */
     
    public Gate getGateById(Long id);
    
    /**
     *
     * @param id
     * @return
     */
    public Station getStationById(Long id);
    
    /**
     *
     * @param id
     * @return
     */
    public TicketMachine getTicketMachineById(Long id);
    
    /**
     *
     * @param id
     * @return
     */
    public RateSchedule getRateScheduleById(Long id);
    
    public List<Gate> getAllGates();
    
    public List<Station> getAllStations();
    
    public List<TicketMachine> getAllTicketMachines();
}

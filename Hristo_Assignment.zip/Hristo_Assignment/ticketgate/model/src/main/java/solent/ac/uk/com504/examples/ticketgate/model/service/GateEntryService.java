package solent.ac.uk.com504.examples.ticketgate.model.service;

import java.util.Date;
import solent.ac.uk.com504.examples.ticketgate.model.dto.Ticket;

/**
 *
 * @author songo
 */
public interface GateEntryService {

    /**
     *
     * @param ticket
     * @param zonesTravelled
     * @param currentTime
     * @return
     */
    public boolean openGate(Ticket ticket, int zonesTravelled, Date currentTime);
    
}

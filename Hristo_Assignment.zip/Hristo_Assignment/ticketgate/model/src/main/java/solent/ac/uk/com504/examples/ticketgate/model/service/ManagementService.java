/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solent.ac.uk.com504.examples.ticketgate.model.service;

import solent.ac.uk.com504.examples.ticketgate.model.dto.Gate;
import solent.ac.uk.com504.examples.ticketgate.model.dto.RateSchedule;
import solent.ac.uk.com504.examples.ticketgate.model.dto.Station;
import solent.ac.uk.com504.examples.ticketgate.model.dto.TicketMachine;

/**
 *
 * @author songo
 */
public interface ManagementService {
    //add new stations, ticketMachines, gates and opening and closing them
    //look at farmfacadeImpl and serviceObjectfactoryImpl
    
    /**
     * 
     * @param stationName type name of the station
     * @param zone station that the station is in 
     * @param rateSchedule peak of peak times
     * @return returns a station 
     */
    public Station addStation(String stationName, int zone, RateSchedule rateSchedule);
    
    /**
     * 
     * @param stationId get station id
     * @return returns a ticketMachine 
     */
    public TicketMachine addTicketMachine(Long stationId);

    /**
     * 
     * @param stationId get station id
     * @return returns a station object
     */
    public Gate addGate(Long stationId);

    /**
     * 
     * @param day get rate schedule day
     * @param hour get rate schedule hour
     * @return returns a station object
     */
    public RateSchedule addRateSchedule(int day, int hour);
     /**
     * open gate
     * @param gate 
     * @return returns a station object
     */
    public boolean openGate(Gate gate);
    
     /**
     * open ticketMachine
     * @param ticketMachine 
     * @return returns a station object
     */
    public boolean openTicketMachine(TicketMachine ticketMachine);
    
     /**
     * close gate
     * @param gate 
     * @return returns a station object
     */
    public boolean closeGate(Gate gate);
    
     /**
     * close ticketMachine
     * @param ticketMachine
     * @return returns a station object
     */
    public boolean closeTicketMachine(TicketMachine ticketMachine);
    
}

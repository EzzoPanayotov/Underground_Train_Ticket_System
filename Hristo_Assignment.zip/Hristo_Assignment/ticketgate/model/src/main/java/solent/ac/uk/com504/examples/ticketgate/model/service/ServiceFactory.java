/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solent.ac.uk.com504.examples.ticketgate.model.service;

/**
 *
 * @author songo
 */
public interface ServiceFactory {
    
    public ManagementService getManagementService();
    
    public TicketMachineService getTicketMachineService();
    
    public ConfigurationService getConfigurationService();
    
    public GateEntryService getGateEntryService();
}

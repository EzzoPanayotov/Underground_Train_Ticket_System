package solent.ac.uk.com504.examples.ticketgate.model.service;

import java.util.Date;
import solent.ac.uk.com504.examples.ticketgate.model.dto.Station;
import solent.ac.uk.com504.examples.ticketgate.model.dto.Ticket;

/**
 *
 * @author songo
 */
public interface TicketMachineService {
    
    /**
     *
     * @param destination
     * @param validFrom
     * @param validTo
     * @param startStation
     * @return
     */
    public Ticket createTicket(Station destination, Date validFrom, Date validTo, Station startStation);
    
    /**
     *
     * @param startStation
     * @param destination
     * @param validFrom
     * @return
     */
    public double getPrice(Station startStation, Station destination, Date validFrom);

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solent.ac.uk.com504.examples.ticketgate.model.test;

import java.io.File;
import java.io.StringWriter;

import java.util.Date;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import static org.junit.Assert.*;
import org.junit.Test;
import solent.ac.uk.com504.examples.ticketgate.model.dto.Ticket;
import solent.ac.uk.com504.examples.ticketgate.model.dto.ReplyMessage;

/**
 *
 * @author songo
 */
public class ModelJaxbTest {

    /**
     *
     */
    @Test
    public void testTransactionJaxb() {

        try {

            // test file we will write and read. 
            // Note in target folder so that will be deleted on each run and will not be saved to git
            File file = new File("target/testData.xml");
            System.out.println("writing test file to " + file.getAbsolutePath());

            // this contains a list of Jaxb annotated classes for the context to parse
            // NOTE you must also have a jaxb.index or ObjectFactory in the same classpath
            JAXBContext jaxbContext = JAXBContext.newInstance("solent.ac.uk.com504.examples.ticketgate.model.dto");

            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

            // output pretty printed
            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

            ReplyMessage replyMessage = new ReplyMessage();
            replyMessage.setCode(Integer.SIZE);
            replyMessage.setDebugMessage("debug message test");
            replyMessage.setUnlocked(Boolean.FALSE);
            
            Ticket ticket = new Ticket();
            String encodedKey = "encoded key";
            ticket.setEncodedKey(encodedKey);
            int zones = 10;
            ticket.setZones(zones);
            
            Long startStation = 1L;
            ticket.setStartStation(startStation);
            Date validFrom = new Date();
            ticket.setValidFrom(validFrom);

            // add 24 hours 1000 ms * 60 secs * 60 mins * 24 hrs to current time
            long validToLong = validFrom.getTime() + 1000 * 60 * 60 * 24;
            Date validTo = new Date(validToLong);

            ticket.setValidTo(validTo);
            replyMessage.setTicket(ticket);

            // create XML from the object
            // marshal the object lists to system out, a file and a stringWriter
            jaxbMarshaller.marshal(replyMessage, System.out);
            jaxbMarshaller.marshal(replyMessage, file);

            // string writer is used to compare received object
            StringWriter sw1 = new StringWriter();
            jaxbMarshaller.marshal(replyMessage, sw1);

            // having written the file we now read in the file for test
            Unmarshaller jaxbUnMarshaller = jaxbContext.createUnmarshaller();
            ReplyMessage receivedTransactionResult = (ReplyMessage) jaxbUnMarshaller.unmarshal(file);

            StringWriter sw2 = new StringWriter();
            jaxbMarshaller.marshal(receivedTransactionResult, sw2);

            // check transmitted and recieved messages are the same
            assertEquals(sw1.toString(), sw2.toString());

        } catch (JAXBException e) {
            throw new RuntimeException("problem testing jaxb marshalling", e);
        }
    }
}

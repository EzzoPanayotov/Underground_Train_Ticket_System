/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solent.ac.uk.com504.examples.ticketgate.model.test;

import java.util.Date;
import org.junit.Test;
import solent.ac.uk.com504.examples.ticketgate.model.dto.Ticket;
import static org.junit.Assert.*;
import org.junit.Test;

/**
 * TEST THAT ticket.toXML and ticket.fromXML both work
 * 
 * create and populate a ticket using new ticket()
 * convert the ticket to an xml string
 * convert the xml string back to a new  ticket
 * check that the data in the two tickets are the same
 * 
 * @author cgallen
 */
public class TicketJaxbTest {

    /**
     * Test that a ticket can be marshalled and un-marshalled to xml using Ticket.toXML() and Ticket.fromXML methods
     */
    @Test
    public void testTicketXML() {
         //TODO ADD TEST CODE HERE
          try {
            // 
            Ticket ticket = new Ticket();
            ticket.setZones(1);
            ticket.setEncodedKey("encodedKey");
            ticket.setValidFrom(new Date());
            ticket.setValidTo(new Date());
            ticket.setStartStation(2L);

            String ticketXML = ticket.toXML();

            Ticket ticket2 = Ticket.fromXML(ticketXML);

            assertEquals(ticket.getZones(), ticket2.getZones());
            assertEquals(ticket.getEncodedKey(), ticket2.getEncodedKey());
            assertEquals(ticket.getValidFrom().getTime() / 1000 * 1000, ticket2.getValidFrom().getTime());
            assertEquals(ticket.getValidTo().getTime() / 1000 * 1000, ticket2.getValidTo().getTime());
            assertEquals(ticket.getStartStation(), ticket2.getStartStation());

        } catch (Exception ex) {
            throw new RuntimeException("Problem testing ticket marshalling", ex);
        }
    }

}

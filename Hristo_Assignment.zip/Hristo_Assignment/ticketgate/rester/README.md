# Rester Files

Install the Rester app in chrome or firefox

[Rester for Firefox extension ](https://addons.mozilla.org/en-GB/firefox/addon/rester/)

[Rester for Chrome extension ](https://chrome.google.com/webstore/detail/rester/eejfoncpjfgmeleakejdcanedmefagga?hl=en)

Import this file to Rester in order to test the rest interface with example POST calls.

[rester-export-postman.json](../rester/rester-export-postman.json)
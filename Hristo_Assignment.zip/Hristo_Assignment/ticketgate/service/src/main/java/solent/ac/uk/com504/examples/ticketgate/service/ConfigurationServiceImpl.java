/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solent.ac.uk.com504.examples.ticketgate.service;

import java.util.List;
import solent.ac.uk.com504.examples.ticketgate.model.dao.ConfigurationDAO;
import solent.ac.uk.com504.examples.ticketgate.model.dto.Gate;
import solent.ac.uk.com504.examples.ticketgate.model.dto.RateSchedule;
import solent.ac.uk.com504.examples.ticketgate.model.dto.Station;
import solent.ac.uk.com504.examples.ticketgate.model.dto.TicketMachine;
import solent.ac.uk.com504.examples.ticketgate.model.service.ConfigurationService;

/**
 *
 * @author songo
 */
public class ConfigurationServiceImpl implements ConfigurationService{
    
    private ConfigurationDAO configDAO = null;
    
    public void setConfigurationDAO(ConfigurationDAO configDAO){
        this.configDAO = configDAO;
    }

    @Override
    public Gate getGateById(Long id) {
        return configDAO.retrieveGateById(id);
    }
    
    @Override
    public Station getStationById(Long id) {
        return configDAO.retrieveStationById(id);
    }

    @Override
    public TicketMachine getTicketMachineById(Long id) {
        return configDAO.retrieveTicketMachineById(id);
    }

    @Override
    public RateSchedule getRateScheduleById(Long id) {
        return configDAO.retrieveRateScheduleById(id);
    }

    @Override
    public List<Gate> getAllGates() {
        return configDAO.retrieveAllGates();
    }

    @Override
    public List<Station> getAllStations() {
        return configDAO.retrieveAllStations();
    }

    @Override
    public List<TicketMachine> getAllTicketMachines() {
        return configDAO.retrieveAllTicketMachines();
    }
    
}

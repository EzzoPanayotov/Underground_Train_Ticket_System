/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solent.ac.uk.com504.examples.ticketgate.service;

import solent.ac.uk.com504.examples.ticketgate.model.dao.ConfigurationDAO;
import solent.ac.uk.com504.examples.ticketgate.model.dto.Gate;
import solent.ac.uk.com504.examples.ticketgate.model.dto.RateSchedule;
import solent.ac.uk.com504.examples.ticketgate.model.dto.Station;
import solent.ac.uk.com504.examples.ticketgate.model.dto.TicketMachine;
import solent.ac.uk.com504.examples.ticketgate.model.service.ManagementService;

/**
 *
 * @author songo
 */
public class ManagementServiceImpl implements ManagementService{

    private ConfigurationDAO configDAO = null;
    
    public void setConfigurationDAO(ConfigurationDAO configDAO){
        this.configDAO = configDAO;
    }

    @Override
    public Station addStation(String stationName, int zone, RateSchedule rateSchedule) {
        if (stationName == null || stationName.isEmpty()) {
            throw new IllegalArgumentException("name cannot be null or empty ");
        }
        if (zone < 1 || zone > 6) {
            throw new IllegalArgumentException("zone number has to be between 1 and 6");
        }
        
        Station station = configDAO.createStation();
        station.setStationName(stationName);
        station.setZone(zone);
        station.setRateSchedule(rateSchedule);
        configDAO.updateOrSave(station);
        return station;
        
    }

    @Override
    public TicketMachine addTicketMachine(Long stationId) {
        TicketMachine ticketMachine = configDAO.createTicketMachine();
        ticketMachine.setStationId(stationId);
        configDAO.updateOrSave(ticketMachine);
        return ticketMachine;
    }

    @Override
    public Gate addGate(Long stationId) {
        Gate gate = configDAO.createGate();
        gate.setStationId(stationId);
        configDAO.updateOrSave(gate);
        return gate;
    }

    @Override
    public boolean openGate(Gate gate) {
        gate.setOpenGate(true);
        configDAO.updateOrSave(gate);
        return true;
    }

    @Override
    public boolean openTicketMachine(TicketMachine ticketMachine) {
        ticketMachine.setOpenTicketMachine(true);
        configDAO.updateOrSave(ticketMachine);
        return true;
    }

    @Override
    public boolean closeGate(Gate gate) {
        gate.setOpenGate(false);
        configDAO.updateOrSave(gate);
        return false;
    }

    @Override
    public boolean closeTicketMachine(TicketMachine ticketMachine) {
         ticketMachine.setOpenTicketMachine(false);
         configDAO.updateOrSave(ticketMachine);
         return false;
    }

    @Override
    public RateSchedule addRateSchedule(int day, int hour) {
        RateSchedule rateSchedule = configDAO.createRateSchedule(day, hour);
        rateSchedule.setId(rateSchedule.getId());
        configDAO.updateOrSave(rateSchedule);
        return rateSchedule;
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solent.ac.uk.com504.examples.ticketgate.service;

import solent.ac.uk.com504.examples.dao.jaxb.DAOJaxbImpl;
import solent.ac.uk.com504.examples.ticketgate.model.dao.ConfigurationDAO;
import solent.ac.uk.com504.examples.ticketgate.model.service.ConfigurationService;
import solent.ac.uk.com504.examples.ticketgate.model.service.GateEntryService;
import solent.ac.uk.com504.examples.ticketgate.model.service.ManagementService;
import solent.ac.uk.com504.examples.ticketgate.model.service.ServiceFactory;
import solent.ac.uk.com504.examples.ticketgate.model.service.TicketMachineService;


/**
 *
 * @author cgallen
 */
public class ServiceFactoryImpl {

    // get a temporary directory to store our dao xml file
    public static final String TMP_DIR = System.getProperty("java.io.tmpdir");

    // dao xml file location
    private static final String DEFAULT_JAXB_FILE = TMP_DIR + "/configList.xml";
    
    private static GateEntryService gateEntryService = null;

    private static TicketMachineService ticketMachineService = null;
    
    private static ManagementServiceImpl managementService = null;
    
    private static ConfigurationServiceImpl configurationService = null;
    
    private static ConfigurationDAO configDAO = new DAOJaxbImpl(DEFAULT_JAXB_FILE);
    
    // these should match the generated file names in pom.xml
    private static final String PUBLIC_KEY_FILE="publicKey";
    private static final String PRIVATE_KEY_FILE="privateKey";

    public static GateEntryService getGateEntryService() {
        if (gateEntryService == null) {
            synchronized (ServiceFactoryImpl.class) {
                if (gateEntryService == null) {
                    String publicKeyFileOnClasspath=PUBLIC_KEY_FILE;
                    gateEntryService = new GateEntryServiceImpl(publicKeyFileOnClasspath);
                }
            }
        }
        return gateEntryService;
    }


    public static TicketMachineService getTicketMachineService() {
        if (ticketMachineService == null) {
            synchronized (ServiceFactoryImpl.class) {
                if (ticketMachineService == null) {
                    String privateKeyFileOnClasspath= PRIVATE_KEY_FILE;
                    ticketMachineService = new TicketMachineServiceImpl(privateKeyFileOnClasspath);
                }
            }
        }
        return ticketMachineService;
    }
    
    
    public static ManagementService getManagementService() {
          if (managementService == null) {
            synchronized (ServiceFactoryImpl.class) {
                if (managementService == null) {
                    managementService = new ManagementServiceImpl();
                    managementService.setConfigurationDAO(configDAO);
                }
            }
        }
        return managementService;
    }

    
    public static ConfigurationService getConfigurationService() {
          if (configurationService == null) {
            synchronized (ServiceFactoryImpl.class) {
                if (configurationService == null) {
                    configurationService = new ConfigurationServiceImpl();
                    configurationService.setConfigurationDAO(configDAO);
                }
            }
        }
        return configurationService;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solent.ac.uk.com504.examples.ticketgate.service;

import solent.ac.uk.com504.examples.dao.jaxb.DAOJaxbImpl;
import solent.ac.uk.com504.examples.ticketgate.model.service.ConfigurationService;
import solent.ac.uk.com504.examples.ticketgate.model.service.ManagementService;
import solent.ac.uk.com504.examples.ticketgate.model.service.TicketMachineService;

/**
 *
 * @author songo
 */
public class ServiceObjectFactoryImpl {
    
        // get a temporary directory to store our dao xml file
    public static final String TMP_DIR = System.getProperty("java.io.tmpdir");

    // dao xml file location
    private static final String DAFAULT_JAXB_FILE = TMP_DIR + "/configList.xml";

    private ManagementServiceImpl managementService = null;
    private TicketMachineServiceImpl ticketMachineService = null;
    private ConfigurationServiceImpl configurationService = null;

    /**
     * Initialises farmFacade objectFactory
     */
    public ServiceObjectFactoryImpl() {
        this(DAFAULT_JAXB_FILE);
    }

    /**
     * Initialises farmFacade objectFactory with a given location for jaxb file
     */
    public ServiceObjectFactoryImpl(String jaxbFile) {

        managementService = new ManagementServiceImpl();
//        AnimalTypeDao animalTypeDao = new AnimalTypeDaoImpl();
        
        // UNCOMMENT THIS TO USE SIMPLE DAO AND COMMENT OUT AnimalDaoJaxbImpl
        // if you just want to use simple DAO do this
//        AnimalDao animalDao = new AnimalDaoImpl();

        // UNCOMMENT THIS TO USE JAXB DAO AND COMMENT OUT AnimalDaoImpl()
        // NOTE THIS IS SAYING WHERE THE FILE GOES in TOMCAT
        DAOJaxbImpl daoJaxbImpl= new DAOJaxbImpl(jaxbFile);

        managementService.setConfigurationDAO(daoJaxbImpl);
    }
    
    
    public ManagementService getManagementService() {
        return managementService;
    }

    
    public TicketMachineService getTicketMachineService() {
        return ticketMachineService;
    }

    
    public ConfigurationService getConfigurationService() {
        return configurationService;
    }
}

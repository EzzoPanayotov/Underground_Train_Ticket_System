/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solent.ac.uk.com504.examples.ticketgate.service;

import solent.ac.uk.com504.examples.ticketgate.crypto.AsymmetricCryptography;
import java.security.PrivateKey;
import java.util.Calendar;
import java.util.Date;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import solent.ac.uk.com504.examples.ticketgate.model.dto.RateSchedule;
import solent.ac.uk.com504.examples.ticketgate.model.dto.Station;
import solent.ac.uk.com504.examples.ticketgate.model.dto.Ticket;
import solent.ac.uk.com504.examples.ticketgate.model.service.TicketMachineService;

/**
 *
 * @author cgallen
 */
public class TicketMachineServiceImpl implements TicketMachineService {

    final static Logger LOG = LogManager.getLogger(TicketMachineServiceImpl.class);

    String privateKeyFileOnClasspath = null;

    public TicketMachineServiceImpl(String privateKeyFileOnClasspath) {
        this.privateKeyFileOnClasspath = privateKeyFileOnClasspath;
    }

    @Override
    public Ticket createTicket(Station destination, Date validFrom, Date validTo, Station startStation) {
        LOG.debug("createTicket called (zones="+destination
                + " validFrom="+validFrom
                + " validTo="+validTo
                + " startStation"+startStation.getId()
                + ")");
        
        if (destination  == null) {
            throw new RuntimeException("zone number has to be between 1 and 6");
        }
        if (validFrom == null) {
            throw new RuntimeException("validFrom must not be null");
        }
        if (validTo == null) {
            throw new RuntimeException("validTo must not be null");
        }
        if (startStation == null) {
            throw new RuntimeException("startStation must not be null");
        }
        

        Ticket ticket = new Ticket();
        int zonesTravelled = startStation.getDistance(destination);
        ticket.setZones(zonesTravelled);
        ticket.setValidFrom(validFrom);
        ticket.setValidTo(validTo);
        ticket.setStartStation(startStation.getId());

        String content = ticket.getContent();

        try {
            AsymmetricCryptography ac = new AsymmetricCryptography();
            PrivateKey privateKey = ac.getPrivateFromClassPath(privateKeyFileOnClasspath);

            String encodeKey = ac.encryptText(content, privateKey);
            ticket.setEncodedKey(encodeKey);
        } catch (Exception ex) {
            throw new RuntimeException("problem encoding ticket:", ex);
        }

        return ticket;

    }

    @Override
    public double getPrice(Station startStation, Station destination, Date validFrom) {
        
        final double perZonePrice = 1.2;

        double basePrice = startStation.getDistance(destination) * perZonePrice;

        RateSchedule rateSchedule = startStation.getRateSchedule();
        
        if(rateSchedule.isOnPeak(Calendar.DAY_OF_WEEK, Calendar.HOUR) && destination.getZone() > 1){
            return basePrice + 2.0;
        }else{
            return basePrice;
        }
    }


}

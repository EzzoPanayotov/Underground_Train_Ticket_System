/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solent.ac.uk.com504.examples.ticketgate.service.test;

import java.util.Date;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;
import solent.ac.uk.com504.examples.ticketgate.model.dto.RateSchedule;
import solent.ac.uk.com504.examples.ticketgate.model.dto.Station;
import solent.ac.uk.com504.examples.ticketgate.model.dto.Ticket;
import solent.ac.uk.com504.examples.ticketgate.service.ServiceFactoryImpl;
import solent.ac.uk.com504.examples.ticketgate.model.service.GateEntryService;
import solent.ac.uk.com504.examples.ticketgate.model.service.ManagementService;
import solent.ac.uk.com504.examples.ticketgate.model.service.TicketMachineService;

/**
 * TESTS OF THE GATE SERVICES
 *
 * TODO YOU NEED TO COMPLETE THE TESTS BELOW WHICH HAVE NO CODE YOUR TEST MUST
 * MEET THE SPECIFICAITON GIVEN IN THE TEST DOCUMENTATION ABOVE EACH TEST METHOD
 */
public class GateServiceTest {

    private TicketMachineService lockManagementService = null;
    private GateEntryService gateEntryService = null;
    private RateSchedule rateSchedule = null;

    private Date validFrom = null;
    private Date validTo = null;

    private Ticket ticket = null;
    private Station station = null;

    @Before
    public void init() {
      lockManagementService = ServiceFactoryImpl.getTicketMachineService();
        assertNotNull(lockManagementService);

        gateEntryService = ServiceFactoryImpl.getGateEntryService();
        assertNotNull(gateEntryService);

        validFrom = new Date(1636977646306L);
        
        rateSchedule = new RateSchedule();
        rateSchedule.setIsOnPeak(0, 7, true);
        rateSchedule.setIsOnPeak(2, 7, true);
        rateSchedule.setIsOnPeak(4, 7, true);
        // test if ticket created
       Station station1 = new Station();
       station1.setId(1L);
       station1.setRateSchedule(rateSchedule);
       station1.setStationName("Waterloo");
       station1.setZone(1);
       
       Station station2 = new Station();
       station2.setId(2L);
       station2.setRateSchedule(rateSchedule);
       station2.setStationName("Edgware");
       station2.setZone(2);
        
        
        // add 24 hours 1000 ms * 60 secs * 60 mins * 24 hrs to current time
        long validToLong = validFrom.getTime() + 1000 * 60 * 60 * 24;
        validTo = new Date(validToLong);

        // create valid ticket for use in tests
        ticket = lockManagementService.createTicket(station2, validFrom, validTo, station1);
        int zonesTravelled = station1.getDistance(station2);
        assertNotNull(ticket);
        
        assertEquals(ticket.getStartStation(), station1.getId());
        assertEquals(ticket.getZones(), zonesTravelled);
        assertEquals(ticket.getValidFrom(), validFrom);
        assertEquals(ticket.getValidTo(), validTo);
        assertEquals(ticket.getContent(), "Ticket{zones=1, startStation=1, validFrom=Mon Nov 15 12:00:46 GMT 2021, validTo=Tue Nov 16 12:00:46 GMT 2021}");
        assertNotNull(ticket.getEncodedKey().isEmpty());
        


    }

    @Test
    public void testInitialisation() {
        // simply tests inititialisation in @before method
    }

    @Test
    public void testgateOpens() {

        Date currentTime = new Date(validFrom.getTime() + 1000 * 60);
        int zonesTravelled = 1;
        boolean open = gateEntryService.openGate(ticket, zonesTravelled, currentTime);
        assertTrue(open);
    }


    @Test
    public void testgateShutWrongZones() {

         Date currentTime = new Date(validFrom.getTime() + 1000 * 60);
         int zonesTravelled = 3;
         boolean open = gateEntryService.openGate(ticket, zonesTravelled, currentTime);
         assertFalse(open);
    }

    @Test
    public void testCurrentTimeBeforeValidFrom() {

         Date currentTime = new Date(validFrom.getTime() - 1000 * 60);
         int zonesTravelled = 1;
         boolean open = gateEntryService.openGate(ticket, zonesTravelled, currentTime);
         assertFalse(open);
    }


    @Test
    public void testCurrentTimeAfterValidTo() {

         Date currentTime = new Date(validFrom.getTime() + 1000 * 60 * 60 * 24 * 2);
         int zonesTravelled = 1;
         boolean open = gateEntryService.openGate(ticket, zonesTravelled, currentTime);
         assertFalse(open);
    }
}

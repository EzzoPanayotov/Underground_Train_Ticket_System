/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solent.ac.uk.com504.examples.ticketgate.service.test;

import org.junit.Test;
import static org.junit.Assert.*;
import solent.ac.uk.com504.examples.ticketgate.model.dto.Gate;
import solent.ac.uk.com504.examples.ticketgate.model.dto.RateSchedule;
import solent.ac.uk.com504.examples.ticketgate.model.dto.Station;
import solent.ac.uk.com504.examples.ticketgate.model.dto.TicketMachine;
import solent.ac.uk.com504.examples.ticketgate.model.service.ConfigurationService;
import solent.ac.uk.com504.examples.ticketgate.model.service.ManagementService;
import solent.ac.uk.com504.examples.ticketgate.service.ServiceFactoryImpl;

/**
 *
 * @author songo
 */
public class ManagementServiceTest {
    ManagementService managementService = null;
    RateSchedule rateSchedule = null;
    ConfigurationService configService = null;
    
    @Test
    public void addRateScheduleTest(){
        managementService = ServiceFactoryImpl.getManagementService();
        assertNotNull(managementService);
        
        RateSchedule schedule = managementService.addRateSchedule(1, 5);
        assertNotNull(schedule);
        
    }
    
    @Test
    public void addStationTest(){
        managementService = ServiceFactoryImpl.getManagementService();
        assertNotNull(managementService);
        
        RateSchedule schedule = managementService.addRateSchedule(1, 5);
        assertNotNull(schedule);
        
        Station station1 = managementService.addStation("Waterloo", 1, schedule);
        
        assertNotNull(station1);
        assertEquals(station1.getStationName(), "Waterloo");
        assertEquals(station1.getZone(), 1);
        assertEquals(station1.getRateSchedule(), schedule);
        
    }
    
    @Test
    public void addTicketMachine(){
        managementService = ServiceFactoryImpl.getManagementService();
        assertNotNull(managementService);
        
        RateSchedule schedule = managementService.addRateSchedule(1, 5);
        assertNotNull(schedule);
        
        Station station = managementService.addStation("Waterloo", 1, schedule);
        assertNotNull(station);
        
        TicketMachine ticketMachine = managementService.addTicketMachine(station.getId());
        assertNotNull(ticketMachine);
        assertEquals(ticketMachine.getStationId(), station.getId());
        
    }
    
    @Test
    public void addGateTest(){
        managementService = ServiceFactoryImpl.getManagementService();
        assertNotNull(managementService);
        
        RateSchedule schedule = managementService.addRateSchedule(1, 5);
        assertNotNull(schedule);
        
        Station station = managementService.addStation("Waterloo", 1, schedule);
        assertNotNull(station);
        
        Gate gate = managementService.addGate(station.getId());
        assertNotNull(gate);
        assertEquals(gate.getStationId(), station.getId());
    }
    
}
